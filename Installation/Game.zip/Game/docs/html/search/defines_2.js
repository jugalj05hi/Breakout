var searchData=
[
  ['brick_5fheight_4253',['BRICK_HEIGHT',['../_brick_8h.html#a885aa654e3f869d7d9d2736b0debcbfb',1,'Brick.h']]],
  ['brick_5fwidth_4254',['BRICK_WIDTH',['../_brick_8h.html#a15bd1a7109dfbc9c82dc540bfd227608',1,'Brick.h']]]
];
