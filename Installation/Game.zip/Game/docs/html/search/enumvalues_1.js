var searchData=
[
  ['khronos_5fboolean_5fenum_5fforce_5fsize_4238',['KHRONOS_BOOLEAN_ENUM_FORCE_SIZE',['../khrplatform_8h.html#a0b823cfbc138820708978d43a5f26c64a47d7d559cf039488acac78e797bc3cf9',1,'khrplatform.h']]],
  ['khronos_5ffalse_4239',['KHRONOS_FALSE',['../khrplatform_8h.html#a0b823cfbc138820708978d43a5f26c64a37d68e7202b4d30f7742acebb50d1ba6',1,'khrplatform.h']]],
  ['khronos_5ftrue_4240',['KHRONOS_TRUE',['../khrplatform_8h.html#a0b823cfbc138820708978d43a5f26c64a9275264520295ae24bc2033c05d6cb70',1,'khrplatform.h']]]
];
