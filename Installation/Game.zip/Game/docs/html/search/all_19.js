var searchData=
[
  ['y_3099',['y',['../struct_point.html#a6101960c8d2d4e8ea1d32c9234bbeb8d',1,'Point::y()'],['../class_vec2.html#a30543787e62f6d915543cf1dfb04c094',1,'Vec2::y()'],['../glad_8h.html#a66ddd433d2cacfe27f5906b7e86faeed',1,'y():&#160;glad.h']]],
  ['y1_3100',['y1',['../glad_8h.html#a48340161068d267815ac3131e9d03def',1,'glad.h']]],
  ['y2_3101',['y2',['../glad_8h.html#af7158b5d27f7a6aa4ab9973fcc3a5c20',1,'glad.h']]],
  ['yfactor_3102',['yfactor',['../glad_8h.html#a35c8ad7bbcca23e97ab9dadfbda4c0c9',1,'glad.h']]],
  ['ymove_3103',['ymove',['../glad_8h.html#ac69eb3ea93058abe33dbca40a84234ed',1,'glad.h']]],
  ['yoffset_3104',['yoffset',['../glad_8h.html#a76dfb6803dcff61037ba688b7f4242b8',1,'glad.h']]],
  ['yorig_3105',['yorig',['../glad_8h.html#a12efb8d14365059e7a8c24a87440d5d7',1,'glad.h']]]
];
