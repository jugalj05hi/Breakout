var searchData=
[
  ['khronos_5fboolean_5fenum_5ft_4236',['khronos_boolean_enum_t',['../khrplatform_8h.html#a0b823cfbc138820708978d43a5f26c64',1,'khrplatform.h']]]
];
