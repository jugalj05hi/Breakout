var searchData=
[
  ['v_3071',['v',['../glad_8h.html#a14cfbe2fc2234f5504618905b69d1e06',1,'glad.h']]],
  ['v0_3072',['v0',['../glad_8h.html#a7062a23d1d434121d4a88f530703d06a',1,'glad.h']]],
  ['v1_3073',['v1',['../glad_8h.html#a0779c3b73f9aa3a0ac5b0139b5d291d9',1,'glad.h']]],
  ['v2_3074',['v2',['../glad_8h.html#a9a09a1837922b2b806f4589096a52049',1,'glad.h']]],
  ['v3_3075',['v3',['../glad_8h.html#acc806b31cbf466ceba6555983d8b814d',1,'glad.h']]],
  ['val_3076',['val',['../glad_8h.html#aa857b95cc76669c2a9109239ef40a47c',1,'glad.h']]],
  ['value_3077',['value',['../glad_8h.html#a03aff08f73d7fde3d1a08e0abd8e84fa',1,'glad.h']]],
  ['values_3078',['values',['../glad_8h.html#a0aa8cf39c79d294b1d9f4daef5020bec',1,'glad.h']]],
  ['varyings_3079',['varyings',['../glad_8h.html#ac4fabc39fa378495cbce6b1b367fc687',1,'glad.h']]],
  ['vec2_3080',['Vec2',['../class_vec2.html',1,'Vec2'],['../class_vec2.html#a76080feed7005893ecc634f903cfbae0',1,'Vec2::Vec2()'],['../class_vec2.html#a6256fecebf5a43b14d5d5341c58cfdc4',1,'Vec2::Vec2(float x, float y)']]],
  ['vec2_2ecpp_3081',['Vec2.cpp',['../_vec2_8cpp.html',1,'']]],
  ['vec2_2eh_3082',['Vec2.h',['../_vec2_8h.html',1,'']]],
  ['velocity_3083',['velocity',['../class_ball.html#ab5da7c8a1d90ecfb433a917071d38bd7',1,'Ball::velocity()'],['../class_paddle.html#a272bc6a57f577cca115ee892bd029658',1,'Paddle::velocity()']]],
  ['vn_3084',['vn',['../glad_8h.html#ac4c724566db0fafb8db8aebec82bfe1f',1,'glad.h']]],
  ['void_3085',['void',['../glad_8h.html#aef30cfca5b4a4c292babb2f60f6d3296',1,'void(APIENTRY *GLDEBUGPROC)(GLenum source:&#160;glad.h'],['../glad_8h.html#a950fc91edb4504f62f1c577bf4727c29',1,'void(APIENTRYP PFNGLCULLFACEPROC)(GLenum mode):&#160;glad.h']]],
  ['vorder_3086',['vorder',['../glad_8h.html#a8d88201263c9c43d2d53f877df9c49b6',1,'glad.h']]],
  ['vstride_3087',['vstride',['../glad_8h.html#a5a7772f7703473eb7376ccb182a0c960',1,'glad.h']]]
];
