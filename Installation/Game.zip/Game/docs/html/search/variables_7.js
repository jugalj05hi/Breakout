var searchData=
[
  ['major_3976',['major',['../structglad_g_lversion_struct.html#ac7f9db11d2679df12ef0313b728554db',1,'gladGLversionStruct']]],
  ['max_5floaded_5fmajor_3977',['max_loaded_major',['../glad_8cpp.html#a9e504bd5bf1cd6a49e3a76a33a58ede4',1,'glad.cpp']]],
  ['max_5floaded_5fminor_3978',['max_loaded_minor',['../glad_8cpp.html#ad98d2ec0df0b5d1256e056d8d663980e',1,'glad.cpp']]],
  ['minor_3979',['minor',['../structglad_g_lversion_struct.html#acc2bff1c8966c6866f2ad6f5a4e475b2',1,'gladGLversionStruct']]]
];
