var searchData=
[
  ['y_4221',['y',['../glad_8h.html#a66ddd433d2cacfe27f5906b7e86faeed',1,'glad.h']]],
  ['y1_4222',['y1',['../glad_8h.html#a48340161068d267815ac3131e9d03def',1,'glad.h']]],
  ['y2_4223',['y2',['../glad_8h.html#af7158b5d27f7a6aa4ab9973fcc3a5c20',1,'glad.h']]],
  ['yfactor_4224',['yfactor',['../glad_8h.html#a35c8ad7bbcca23e97ab9dadfbda4c0c9',1,'glad.h']]],
  ['ymove_4225',['ymove',['../glad_8h.html#ac69eb3ea93058abe33dbca40a84234ed',1,'glad.h']]],
  ['yoffset_4226',['yoffset',['../glad_8h.html#a76dfb6803dcff61037ba688b7f4242b8',1,'glad.h']]],
  ['yorig_4227',['yorig',['../glad_8h.html#a12efb8d14365059e7a8c24a87440d5d7',1,'glad.h']]]
];
