var searchData=
[
  ['reset_3204',['Reset',['../class_ball.html#ab16d8f8c98ddd13ed0350d40cf8e104e',1,'Ball::Reset()'],['../class_paddle.html#a9e8f3470599c6244ed39a3b29cda904f',1,'Paddle::Reset()']]]
];
