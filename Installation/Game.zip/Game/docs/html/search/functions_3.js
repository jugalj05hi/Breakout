var searchData=
[
  ['find_5fcoregl_3152',['find_coreGL',['../glad_8cpp.html#a1e6b94e667c5087bcd17801e4e4942a3',1,'glad.cpp']]],
  ['find_5fextensionsgl_3153',['find_extensionsGL',['../glad_8cpp.html#aec888869187731b49111dfbea5f7cd56',1,'glad.cpp']]],
  ['flipdirectionx_3154',['FlipDirectionX',['../class_ball.html#a1696e83d2999a0587379e083a4d22e25',1,'Ball']]],
  ['flipdirectiony_3155',['FlipDirectionY',['../class_ball.html#ac3a7adff5d0a8ad4accf0e3354714f57',1,'Ball']]],
  ['free_5fexts_3156',['free_exts',['../glad_8cpp.html#a250a03ed54f517313be3fb311c1d0929',1,'glad.cpp']]]
];
