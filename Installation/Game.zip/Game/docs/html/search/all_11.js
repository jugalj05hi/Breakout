var searchData=
[
  ['q_2997',['q',['../glad_8h.html#a514729309336df22bcc8eda979d6ced4',1,'glad.h']]],
  ['query_2998',['query',['../glad_8h.html#a142beaaf360375a3437a83a5aa8ecf06',1,'glad.h']]]
];
