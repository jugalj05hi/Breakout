var searchData=
[
  ['offset_4132',['offset',['../glad_8h.html#ae1b92ae085ddef4b1cdca7d749339fb0',1,'glad.h']]],
  ['order_4133',['order',['../glad_8h.html#a4240946665c1034f7ba768c9bf5af8ec',1,'glad.h']]]
];
