var searchData=
[
  ['unpause_3216',['unpause',['../class_l_timer.html#a67a946bffb25cf5eb8ab430ffb5f7cec',1,'LTimer']]],
  ['update_3217',['update',['../class_brick.html#abad34aace76f3c71df2732667f015535',1,'Brick::update()'],['../class_ball.html#a791a8547e5a882d05c1acc4cbfcee86b',1,'Ball::Update()'],['../class_paddle.html#a1c4a690ba356e1536a581533cec7a6cb',1,'Paddle::Update()']]]
];
