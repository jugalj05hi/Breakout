var searchData=
[
  ['spritesheet_3989',['spriteSheet',['../class_ball.html#a6c3977a9020108009eda3746b8f90c35',1,'Ball']]]
];
