var searchData=
[
  ['y_3998',['y',['../struct_point.html#a6101960c8d2d4e8ea1d32c9234bbeb8d',1,'Point::y()'],['../class_vec2.html#a30543787e62f6d915543cf1dfb04c094',1,'Vec2::y()']]]
];
