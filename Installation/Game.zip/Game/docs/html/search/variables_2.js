var searchData=
[
  ['exts_3229',['exts',['../glad_8cpp.html#a866827ab8f22713c7232944595e94906',1,'glad.cpp']]],
  ['exts_5fi_3230',['exts_i',['../glad_8cpp.html#a08801e74281bbcbf8a58ac37ddd1def8',1,'glad.cpp']]]
];
