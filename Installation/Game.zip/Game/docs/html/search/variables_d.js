var searchData=
[
  ['velocity_3993',['velocity',['../class_ball.html#ab5da7c8a1d90ecfb433a917071d38bd7',1,'Ball::velocity()'],['../class_paddle.html#a272bc6a57f577cca115ee892bd029658',1,'Paddle::velocity()']]]
];
