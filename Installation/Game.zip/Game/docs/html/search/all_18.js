var searchData=
[
  ['x_3094',['x',['../struct_point.html#a05dfe2dfbde813ad234b514f30e662f1',1,'Point::x()'],['../class_vec2.html#adf8ee322d4b4bcc04146762c018d731f',1,'Vec2::x()'],['../glad_8h.html#a92d0386e5c19fb81ea88c9f99644ab1d',1,'x():&#160;glad.h']]],
  ['x2_3095',['x2',['../glad_8h.html#ad2cea6eadb01f017f0d57e7edf0ce988',1,'glad.h']]],
  ['xmove_3096',['xmove',['../glad_8h.html#a660a4b1a65b57e4184add3d2557c6bf0',1,'glad.h']]],
  ['xoffset_3097',['xoffset',['../glad_8h.html#ac20a0ffebf4c476650fcfa0633066f0e',1,'glad.h']]],
  ['xorig_3098',['xorig',['../glad_8h.html#aab7afbca05528ca0c22440fe04f81f54',1,'glad.h']]]
];
