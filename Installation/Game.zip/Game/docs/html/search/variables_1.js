var searchData=
[
  ['defaultposition_3227',['defaultPosition',['../class_ball.html#a7980728f324facd60e3cdda5451ccd76',1,'Ball']]],
  ['defaultvelocity_3228',['defaultVelocity',['../class_ball.html#a803a1b022ab6466d4354a7b518d8a150',1,'Ball']]]
];
