var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "bcglprv",
  2: "bcgklprv",
  3: "bcdfghilmoprsuv~",
  4: "bdefghlmnprstvwxy",
  5: "abcdefghijklmnopqrstuvwxyz",
  6: "bck",
  7: "bklmnprt",
  8: "_abgks"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

