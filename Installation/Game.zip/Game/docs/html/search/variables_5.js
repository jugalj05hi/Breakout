var searchData=
[
  ['height_3971',['height',['../class_ball.html#afe4267531b1e97c17591792ee52fec5b',1,'Ball']]],
  ['hit_3972',['hit',['../class_brick.html#a797c9d32f6b379bd0d5c18a4633e85bc',1,'Brick']]]
];
